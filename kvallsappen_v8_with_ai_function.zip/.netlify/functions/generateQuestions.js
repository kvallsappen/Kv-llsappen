const fetch = require('node-fetch');

exports.handler = async function(event, context) {
  const userPrompt = JSON.parse(event.body).prompt;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer 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'
    },
    body: JSON.stringify({
      model: 'gpt-4',
      messages: [{ role: 'user', content: userPrompt }],
      max_tokens: 200
    })
  });

  const data = await response.json();
  return {
    statusCode: 200,
    body: JSON.stringify({ result: data.choices[0].message.content })
  };
};
