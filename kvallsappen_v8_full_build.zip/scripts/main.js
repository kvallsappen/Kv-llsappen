
function generateAI() {
  const prompt = document.getElementById("aiPrompt").value;
  fetch("/.netlify/functions/generateQuestions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt })
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById("aiResult").innerText = data.result || "Inget svar.";
  })
  .catch(err => {
    document.getElementById("aiResult").innerText = "Fel uppstod: " + err.message;
  });
}
